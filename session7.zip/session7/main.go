package main

import "session7/demo_json"

func main() {
	demo_json.Demo()
}
